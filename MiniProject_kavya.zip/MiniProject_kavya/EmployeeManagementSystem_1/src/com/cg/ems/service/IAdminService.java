package com.cg.ems.service;

import java.util.List;

import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employee;

public interface IAdminService {

	boolean addEmployee(Employee employee) throws EMSException;
	boolean fetchEmployee(String empId)throws EMSException;
	boolean updateEmployee(String empId, Employee employee) throws EMSException;
	List<Employee> dispalyAll() throws EMSException;
	
	

}
