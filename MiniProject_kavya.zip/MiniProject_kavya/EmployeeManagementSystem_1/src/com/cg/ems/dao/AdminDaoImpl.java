package com.cg.ems.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employee;
import com.cg.ems.util.ConnectionProvider;

public class AdminDaoImpl implements IAdminDao {

	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet resultSet;
	private String mgrId;

	@Override
	public boolean addEmployee(Employee employee) throws EMSException {
		connection = ConnectionProvider.getConnection();

		boolean flag = false;
		try {
			statement = connection
					.prepareStatement(IQueryMapper.insertEmployee);

			statement.setString(1, employee.getEmployeeId());

			statement.setString(2, employee.getEmpFName());
			statement.setString(3, employee.getEmpLName());
			Date empDob = new Date(employee.getEmpDOB().getTime());
			statement.setDate(4, empDob);
			Date empDoj = new Date(employee.getEmpDOJ().getTime());
			statement.setDate(5, empDoj);
			statement.setInt(6, employee.getDeptId());
			statement.setString(7, employee.getEmpGrade());
			statement.setString(8, employee.getEmpDesignation());
			statement.setInt(9, employee.getEmpBasic());
			statement.setString(10, employee.getEmpGender());
			statement.setString(11, employee.getEmpMStatus());
			statement.setString(12, employee.getHomeAddr());
			statement.setString(13, employee.getEmpCNumber());
			statement.setString(14, employee.getMrgId());

			int result = statement.executeUpdate();

			if (result > 0) {
				// logger.debug("account created");
				flag = true;
			}

		} catch (SQLException e) {
			/*
			 * // logger.error("statemnt object not created");
			 */throw new EMSException("statement not created with som problem");
		}

		return flag;
	}

	@Override
	public boolean updateEmployee(String EmployeeId,Employee employee) throws EMSException {
		connection = ConnectionProvider.getConnection();
		boolean flag = false;

		try {
			System.out.println("connection");
			statement = connection.prepareStatement(IQueryMapper.updateEmployee);
			System.out.println("connection1");
			statement.setString(1, employee.getEmployeeId());
			statement.setString(2, employee.getEmpFName());
			statement.setString(3, employee.getEmpLName());
			Date empDob = new Date(employee.getEmpDOB().getTime());
			statement.setDate(4, empDob);
			Date empDoj = new Date(employee.getEmpDOJ().getTime());
			statement.setDate(5, empDoj);
			statement.setInt(6, employee.getDeptId());
			statement.setString(7, employee.getEmpGrade());
			statement.setString(8, employee.getEmpDesignation());
			statement.setInt(9, employee.getEmpBasic());
			statement.setString(10, employee.getEmpGender());
			statement.setString(11, employee.getEmpMStatus());
			statement.setString(12, employee.getHomeAddr());
			statement.setString(13, employee.getEmpCNumber());
			statement.setString(14, employee.getMrgId());
			System.out.println("connection22");
				int res = statement.executeUpdate();

				System.out.println(res + " details updated");
				System.out.println("connection33");


		} catch (SQLException e) {
			throw new EMSException("Update query not working");
		}

		return flag;
	}

	@Override
	public boolean fetchEmployee(String empId) throws EMSException {
		boolean flag = false;
		connection = ConnectionProvider.getConnection();
		try {
			statement = connection.prepareStatement(IQueryMapper.fetchEmployeeQuery);

			statement.setString(1, empId);
			System.out.println(empId);
			resultSet = statement.executeQuery();
		
			if (resultSet.next()) {

				flag = true;
			}

		} catch (SQLException e) {

			throw new EMSException("Fetching query not working");
		}
		return flag;

	}

	@Override
	public List<Employee> displayAll() throws EMSException {
		List<Employee> list = new ArrayList<Employee>();
		connection = ConnectionProvider.getConnection();
		try {
			statement = connection.prepareStatement(IQueryMapper.displayEmployees);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				String id = resultSet.getString(1);
				String fName = resultSet.getString(2);
				String lName = resultSet.getString(3);
				Date dob = resultSet.getDate(4);
				Date doj = resultSet.getDate(5);
				int dept = resultSet.getInt(6);
				String grade = resultSet.getString(7);
				String designation = resultSet.getString(8);
				int salary = resultSet.getInt(9);
				String gender = resultSet.getString(10);
				String marital = resultSet.getString(11);
				String addr = resultSet.getString(12);
				String phNo = resultSet.getString(13);
				String mgrId = resultSet.getString(14);

				Employee employee = new Employee(id, fName, lName, dob, doj,
						dept, grade, designation, salary, gender, marital,
						addr, phNo, mgrId);

				list.add(employee);
			}
		} catch (SQLException e) {
			throw new EMSException("Display employee query not working");
		}

		return list;
	}
}
