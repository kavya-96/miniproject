package com.cg.ems.presentation;


import java.util.Scanner;


public class Controller {
	 static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) {
		
		int choice = -1;
		while(choice!=2 ){
			System.out.print("[1]Login [2]LogOut >");
			choice = scanner.nextInt();
			if(choice==1){
			
			System.out.println("Login Page");
			System.out.println("Enter User Name:");
			String userName=scanner.next();
			
			System.out.println("Enter password");
			String password=scanner.next();
			try {
				
				if((userName.equals("a"))&&(password.equals("123")))
				{
					AdminConsole ac = new AdminConsole(userName);
					ac.start();
					System.out.println("**");
				}else{
					EmployeeConsole emp = new EmployeeConsole(userName);
					emp.start();
				}					
			} 
			catch(Exception e){
				System.err.println(e.getMessage());
			}				
		}
	}
	scanner.close();
	System.out.println("Program Terminated");
}	

}