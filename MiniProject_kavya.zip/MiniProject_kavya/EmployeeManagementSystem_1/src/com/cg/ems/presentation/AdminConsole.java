package com.cg.ems.presentation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employee;
import com.cg.ems.service.AdminServiceImpl;
import com.cg.ems.service.IAdminService;

public class AdminConsole {

	private String currentUser;

	public AdminConsole(String currentUser) {
		super();
		this.currentUser = currentUser;
	}

	static Scanner scanner = new Scanner(System.in);
	IAdminService adminService = new AdminServiceImpl();

	public void start() {
		System.out.println("Welcome " + currentUser);

		int choice = 0;

		// while (choice != 5) {

		System.out.println("Menu:");
		System.out.println("Enter 1 for add details of employee");

		System.out.println("Enter 2 for updating employee details");
		System.out.println("Enter 3 for displaying all Employee details");
		System.out.println("Enter 4 for Exit");
		System.out.println("Enter your choice: ");
		choice = scanner.nextInt();

		switch (choice) {
		case 1:
			addEmployee();

			break;

		case 2:
			updateEmployee();
			break;
		case 3:
			displayEmployees();
			break;
		}
		// }

	}

	private void displayEmployees() {
		List<Employee> list1;
		try {
			list1 = adminService.dispalyAll();
			if (list1.isEmpty()) {
				System.out.println("No details are updated");
			} else {
				System.out.println("The details are: ");
				System.out.println(list1);
			}
		} catch (EMSException e) {
			System.err.println(e.getMessage());
		}
	}

	private void addEmployee() {

		System.out.println("Enter Employee Id :");
		int id = scanner.nextInt();
		System.out.println("Enter Employee First Name :");
		scanner.nextLine();
		String empFirstName = scanner.nextLine();
		System.out.println("Enter Employee Last Name :");
		String empLastName = scanner.nextLine();
		System.out.println("Enter Employee DOB :");
		String dob = scanner.nextLine();
		System.out.println("Enter date of joining");
		String doj = scanner.nextLine();
		System.out.println("Enter employee department id");
		int empDeptId = scanner.nextInt();
		scanner.nextLine();
		System.out.println("Enter employee grade");
		String empGrade = scanner.nextLine();
		System.out.println("Enter employee designation");
		String empDesign = scanner.nextLine();
		System.out.println("Enter employee salary");
		int empSalary = scanner.nextInt();
		scanner.nextLine();
		System.out.println("Enter employee gender");
		String empGender = scanner.nextLine();
		System.out.println("Enter employee marital status");
		String empMarStatus = scanner.nextLine();
		System.out.println("Enter employee address");
		String empAddress = scanner.nextLine();
		System.out.println("Enter employee contact number");
		String empPhNo = scanner.nextLine();
		System.out.println("Enter employee manager Id");
		int empMgrId = scanner.nextInt();

	}

	private void updateEmployee()  {
		scanner.nextLine();
		System.out.println("Enter Employee Id :");
		String empId = scanner.nextLine();
		try {
			boolean res = adminService.fetchEmployee(empId);
			if (res) {

				Boolean result = adminService.updateEmployee(empId,askDetails());
				if (result) {
					System.out.println("Details updated");
				}
			} else {

				throw new EMSException("no such id");
			}

		} catch (EMSException e) {

			System.err.println(e.getMessage());
		}

	}

	public Employee askDetails() {

		Employee employee = null;
		System.out.println("Enter Employee First Name :");
		String empFirstName = scanner.nextLine();
		System.out.println("Enter Employee Last Name :");
		String empLastName = scanner.nextLine();
		System.out.println("Enter Employee DOB :");
		String empDob = scanner.nextLine();
		System.out.println("Enter date of joining");
		String empDOJ = scanner.nextLine();
		System.out.println("Enter employee department id");
		int empDeptId = scanner.nextInt();
		scanner.nextLine();
		System.out.println("Enter employee grade");
		String empGrade = scanner.nextLine();
		System.out.println("Enter employee designation");
		String empDesign = scanner.nextLine();
		System.out.println("Enter employee salary");
		int empSalary = scanner.nextInt();
		scanner.nextLine();
		System.out.println("Enter employee gender");
		String empGender = scanner.nextLine();
		System.out.println("Enter employee marital status");
		String empMarStatus = scanner.nextLine();
		System.out.println("Enter employee address");
		String empAddress = scanner.nextLine();
		System.out.println("Enter employee contact number");
		String empPhNo = scanner.nextLine();
		System.out.println("Enter employee manager Id");
		String empMgrId = scanner.nextLine();
		try {
			SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
			Date dob = format.parse(empDob);
			Date doj;
			doj = format.parse(empDOJ);
			employee = new Employee(empFirstName, empLastName, dob, doj,
					empDeptId, empGrade, empDesign, empSalary, empGender,
					empMarStatus, empAddress, empPhNo, empMgrId);
		} catch (ParseException e) {

			e.printStackTrace();
		}

		return employee;

	}
}
