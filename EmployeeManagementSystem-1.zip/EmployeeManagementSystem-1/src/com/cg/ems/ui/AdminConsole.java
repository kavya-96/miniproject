package com.cg.ems.ui;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employee;
import com.cg.ems.model.LeaveHistory;
import com.cg.ems.service.AdminServiceImpl;
import com.cg.ems.service.EmployeeServiceImpl;
import com.cg.ems.service.IAdminService;
import com.cg.ems.service.IEmployeeService;


public class AdminConsole {

	Scanner scanner = new Scanner(System.in);
	private String user;
	IAdminService adminService = new AdminServiceImpl();
	IEmployeeService employeeService = new EmployeeServiceImpl();

	public AdminConsole(String user) {
		this.user = user;
	}

	public void start() throws ParseException, EMSException {

		System.out.println("Welcome " + user);
		System.out.println("---------------");

		int choice = 0;

		while (choice != 5) {

			System.out.println("Menu:");
			System.out.println("Enter 1 for add details of employee");

			System.out.println("Enter 2 for updating employee details");
			System.out.println("Enter 3 for displaying all Employee details");
			System.out.println("Enter 4 for view applied leaves");
			System.out.println("Enter 5 for approve leaves");
			System.out.println("Enter your choice: ");
			choice = scanner.nextInt();

			switch (choice) {
			case 1:
				addEmployee();
				break;
			case 2:
				modifyEmployee();
				break;
			case 3:
				viewAllEmployees();
				break;
			case 4:
				viewAppliedLeaves();
				break;
			case 5:
				leaveApproval();
				break;
			case 6:
				System.out.print("Thank you!!");
				System.exit(0);
			default:
				System.out.println("\nPlease enter a valid option[1-6]\n");

			}
		}

	}

	public void addEmployee() {
		Employee employee = null;
		String empId = null;
		while (employee == null) {
			try {
				employee = populateEmployee();
			} catch (ParseException e) {
				System.err.println(e.getMessage());
			}
		}

		try {
			IAdminService adminService = new AdminServiceImpl();
			empId = adminService.addEmployee(employee);

			System.out
					.println("Employee details have been successfully registered! ");
			System.out.println("Employee ID is: " + empId);

		} catch (EMSException employeeException) {
			// logger.error("Exception occured", employeeException);
			System.out.println("ERROR : " + employeeException.getMessage());
		} finally {
			empId = null;
			adminService = null;
			employee = null;
		}
	}

	private void leaveApproval() throws EMSException {
		List<LeaveHistory> leave = viewAppliedLeaves();
		if (leave != null) {
			IAdminService adminService = new AdminServiceImpl();
			System.out.println("Enter the leave id");
			int leaveId = scanner.nextInt();
			System.out.println("1.Approve 2.Reject");
			int option = scanner.nextInt();
			boolean status;
			if (option == 1) {
				status = adminService.leaveSanction(leaveId, "approved");
			} else
				status = adminService.leaveSanction(leaveId, "rejected");
			if (status) {
				System.out.println("Operation performed successfully");
			} else {
				System.out.println("Operation failed. Enter valid leave id");
			}
		}
	}

	private List<LeaveHistory> viewAppliedLeaves() throws EMSException {
		List<LeaveHistory> leaveList = adminService.viewLeaveApplications();
		if (leaveList != null) {
			for (LeaveHistory leave : leaveList) {
				System.out.println(leave);
			}
			return leaveList;
		} else {
			System.out.println("No Records Found!");
			return null;
		}
	}

	private void viewAllEmployees() {
		employeeService = new EmployeeServiceImpl();
		try {
			List<Employee> employeeList = new ArrayList<Employee>();
			employeeList = employeeService.retriveAllDetails();

			if (employeeList != null) {
				Iterator<Employee> i = employeeList.iterator();
				while (i.hasNext()) {

					displayEmployee(i.next());
				}
			} else {
				System.out.println("No Employees in the system.");
			}

		}

		catch (EMSException e) {

			System.out.println("Error  :" + e.getMessage());
		}
	}

	private void modifyEmployee() throws EMSException {
		employeeService = new EmployeeServiceImpl();
		Employee employee = null;
		System.out.println("Enter employee id:");
		String empId = scanner.next();

		employee = getEmployeeById(empId);

		if (employee != null) {

			System.out.println("First Name  :" + employee.getEmpFName());
			employee.setEmpFName(updateAction(employee.getEmpFName()));

			System.out.println("Last Name  :" + employee.getEmpLName());
			employee.setEmpLName(updateAction(employee.getEmpLName()));

			System.out.println("Department Id  :" + employee.getDeptId());
			employee.setDeptId(updateActionInt(employee.getDeptId()));

			System.out.println("Employee Grade  :" + employee.getEmpGrade());
			employee.setEmpGrade(updateAction(employee.getEmpGrade()));

			System.out.println("Designation  :" + employee.getEmpDesignation());
			employee.setEmpDesignation(updateAction(employee.getEmpDesignation()));

			System.out.println("Basic Salary  :" + employee.getEmpBasic());
			employee.setEmpBasic(updateActionInt(employee
					.getEmpBasic()));

			System.out.println("Marital Status  :"
					+ employee.getEmpMStatus());
			employee.setEmpMStatus(updateAction(employee.getEmpMStatus()));

			System.out.println("Home Address  :" + employee.getHomeAddr());
			employee.setHomeAddr(updateAction(employee.getHomeAddr()));

			System.out.println("Contact Number  :" + employee.getEmpCNumber());
			employee.setEmpCNumber(updateAction(employee.getEmpCNumber()));

			System.out.println("Manager Id  :" + employee.getMrgId());
			employee.setMrgId(updateAction(employee.getMrgId()));

			Employee emp = adminService.updateEmployeeById(employee);
			System.out.println("Updated Employee Details");
			System.out.println("-----------------------------------------");
			displayEmployee(emp);

		} else {
			System.err
					.println("There are no employee details associated with employee id "
							+ empId);
		}
	}

	public Employee populateEmployee() throws ParseException {

		// Reading and setting the values for the Employee

		Employee employee = new Employee();
		EmployeeServiceImpl employeeServiceImpl=new EmployeeServiceImpl();

		System.out.println("\n Enter Details");

		System.out.println("Enter employee id: ");
		employee.setEmployeeId(scanner.next());

		scanner.nextLine();
		System.out.println("Enter first name: ");
		employee.setEmpFName(scanner.nextLine());

		System.out.println("Enter last name: ");
		employee.setEmpLName(scanner.next());

		System.out.println("Enter Date of birth(dd-MM-YYYY): ");
		String dateString = scanner.next();
		DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		Date date = new Date();
		try {
			date = formatter.parse(dateString);
		} catch (ParseException e) {
			System.out.println(e.getMessage());
		}
		employee.setEmpDOB(date);

		System.out.println("Enter Date of joining(dd-MM-YYYY): ");
		String dateString1 = scanner.next();
		DateFormat formatter1 = new SimpleDateFormat("dd-MM-yyyy");
		Date date1 = new Date();
		try {
			date1 = formatter1.parse(dateString1);
		} catch (ParseException e) {
			System.out.println(e.getMessage());
		}
		employee.setEmpDOJ(date1);

		System.out.println("Enter department id: ");
		employee.setDeptId(scanner.nextInt());

		System.out.println("Enter Employee grade ");
		employee.setEmpGrade(scanner.next());

		scanner.nextLine();
		System.out.println("Enter designation: ");
		employee.setEmpDesignation(scanner.nextLine());

		System.out.println("Enter Basic salary: ");
		employee.setEmpBasic(scanner.nextInt());

		System.out.println("Enter gender(M/F): ");
		employee.setEmpGender(scanner.next());

		System.out.println("Enter Marital Status(M/U): ");
		employee.setEmpMStatus(scanner.next());

		scanner.nextLine();
		System.out.println("Enter Home Address: ");
		employee.setHomeAddr(scanner.nextLine());

		System.out.println("Enter contact Number: ");
		employee.setEmpCNumber(scanner.next());

		System.out.println("Enter Manager Id: ");
		employee.setMrgId(scanner.next());

		

		try {
			employeeServiceImpl.validateEmployee(employee);
			return employee;
		} catch (EMSException employeeException) {
			//logger.error("exception occured", employeeException);
			System.err.println("Invalid data:");
			System.err.println(employeeException.getMessage()
					+ " \n Try again..");
			System.exit(0);

		}
		return employee;
	}

	public void displayEmployee(Employee employee) {

		System.out.println("Employee Id  :" + employee.getEmployeeId());
		System.out.println("First Name  :" + employee.getEmpFName());
		System.out.println("Last Name  :" + employee.getEmpLName());
		System.out.println("Date of Birth :" + employee.getEmpDOB());
		System.out.println("Date of Joining  :" + employee.getEmpDOJ());
		System.out.println("Department Id  :" + employee.getDeptId());
		System.out.println("Employee Grade  :" + employee.getEmpGrade());
		System.out.println("Designation  :" + employee.getEmpDesignation());
		System.out.println("Basic Salary  :" + employee.getEmpBasic());
		System.out.println("Gender  :" + employee.getEmpGender());
		System.out.println("Marital Status  :" + employee.getEmpMStatus());
		System.out.println("Home Address  :" + employee.getHomeAddr());
		System.out.println("Contact Number  :" + employee.getEmpCNumber());
		System.out.println("Manager Id  :" + employee.getMrgId());
		System.out.println("-----------------------------------------");
	}

	public String updateAction(String initValue) {

		System.out.println("Is update required?(Y/N)");
		String option = scanner.next();
		String updatedValue = null;
		switch (option) {
		case "Y":
			System.out.println("Enter new value");
			updatedValue = scanner.next();
			break;
		case "N":
			updatedValue = initValue;
			break;
		default:
			System.out.println("Enter a valid option(Y/N)");
			updatedValue = updateAction(initValue);
		}
		return updatedValue;

	}

	public int updateActionInt(int initValue) {
		System.out.println("Is update required?(Y/N)");
		String option = scanner.next();
		int updatedValue = 0;
		switch (option) {
		case "Y":
			System.out.println("Enter new value");
			updatedValue = scanner.nextInt();
			break;
		case "N":
			updatedValue = initValue;
			break;
		default:
			System.out.println("Enter a valid option");
		}
		return updatedValue;
	}

	public double updateActionDouble(double initValue) {
		System.out.println("Is update required?(Y/N)");
		String option = scanner.next();
		double updatedValue = 0;
		switch (option) {
		case "Y":
			System.out.println("Enter new value");
			updatedValue = scanner.nextDouble();
			break;
		case "N":
			updatedValue = initValue;
			break;
		default:
			System.out.println("Enter a valid option");
		}
		return updatedValue;
	}

	public Employee getEmployeeById(String employeeId) {
		Employee employee = null;
		employeeService = new EmployeeServiceImpl();

		try {
			employee = employeeService.viewEmployeeById(employeeId);
		} catch (EMSException employeeException) {
			//logger.error("exception occured ", employeeException);
			System.out.println("ERROR : " + employeeException.getMessage());
		}

		return employee;
	}

}
