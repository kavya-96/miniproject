package com.cg.ems.model;

import java.time.LocalDate;
import java.util.Date;

public class LeaveHistory {

	private int LeaveId;
	private int LeaveBalance;
	private int noofdays;
	private LocalDate dateFrom;
	private String status;
	private String EmpId;
	public int getLeaveId() {
		return LeaveId;
	}
	public void setLeaveId(int leaveId) {
		LeaveId = leaveId;
	}
	public int getLeaveBalance() {
		return LeaveBalance;
	}
	public void setLeaveBalance(int leaveBalance) {
		LeaveBalance = leaveBalance;
	}
	public int getNoofdays() {
		return noofdays;
	}
	public void setNoofdays(int noofdays) {
		this.noofdays = noofdays;
	}
	public LocalDate getDateFrom() {
		return dateFrom;
	}
	public void setDateFrom(LocalDate dateFrom) {
		this.dateFrom = dateFrom;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getEmpId() {
		return EmpId;
	}
	public void setEmpId(String empId) {
		EmpId = empId;
	}
	public LeaveHistory(int leaveId, int leaveBalance, int noofdays,
			LocalDate dateFrom, String status, String empId) {
		super();
		LeaveId = leaveId;
		LeaveBalance = leaveBalance;
		this.noofdays = noofdays;
		this.dateFrom = dateFrom;
		this.status = status;
		EmpId = empId;
	}
	public LeaveHistory() {
		super();
		
	}
	
	

}
	