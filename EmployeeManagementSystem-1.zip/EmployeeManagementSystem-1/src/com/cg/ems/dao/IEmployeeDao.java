package com.cg.ems.dao;

import java.util.List;

import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employee;
import com.cg.ems.model.LeaveHistory;


public interface IEmployeeDao {

	public int applyLeave(LeaveHistory leaveHistory) throws EMSException;

	public Employee viewEmployeeById(String empId) throws EMSException;

	public Employee viewEmployeeByFname(String firstName) throws EMSException;

	public Employee viewEmployeeByLname(String lastName) throws EMSException;

	public List<Employee> viewEmployeeByDeptName(String deptName)
			throws EMSException;

	public List<Employee> viewEmployeeByGrade(String empGrade)
			throws EMSException;

	public List<Employee> viewEmployeeByMaritalStatus(String maritalStatus)
			throws EMSException;


	public List<Employee> retriveAllDetails() throws EMSException;
}

	

