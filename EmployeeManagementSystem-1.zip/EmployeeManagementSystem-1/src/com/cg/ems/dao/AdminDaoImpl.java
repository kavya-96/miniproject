package com.cg.ems.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employee;
import com.cg.ems.model.LeaveHistory;
import com.cg.ems.util.ConnectionProvider;




public class AdminDaoImpl implements IAdminDao{

	Logger logger = Logger.getLogger(AdminDaoImpl.class);
	Connection connection=null;
	PreparedStatement statement=null;
	@Override
	public String addEmployee(Employee employee) throws EMSException {
		Connection connection = ConnectionProvider.getConnection();

		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatement1 = null;

		java.sql.Date sqlDOB = new java.sql.Date(employee.getEmpDOB()
				.getTime());
		java.sql.Date sqlDOJ = new java.sql.Date(employee.getEmpDOJ()
				.getTime());

		String empId = null;
		int queryResult = 0;
		int queryResult1 = 0;

		try {
			preparedStatement = connection.prepareStatement(IQueryMapper.ADD_EMPLOYEE);

			preparedStatement.setString(1, employee.getEmployeeId());
			preparedStatement.setString(2, employee.getEmpFName());
			preparedStatement.setString(3, employee.getEmpLName());
			preparedStatement.setDate(4, sqlDOB);
			preparedStatement.setDate(5, sqlDOJ);
			preparedStatement.setInt(6, employee.getDeptId());
			preparedStatement.setString(7, employee.getEmpGrade());
			preparedStatement.setString(8, employee.getEmpDesignation());
			preparedStatement.setDouble(9, employee.getEmpBasic());
			preparedStatement.setString(10, employee.getEmpGender());
			preparedStatement.setString(11, employee.getEmpMStatus());
			preparedStatement.setString(12, employee.getHomeAddr());
			preparedStatement.setString(13, employee.getEmpCNumber());
			preparedStatement.setString(14, employee.getMrgId());
			preparedStatement.setInt(15, 12);

			queryResult = preparedStatement.executeUpdate();
			empId = employee.getEmployeeId();

			preparedStatement1 = connection.prepareStatement(IQueryMapper.ADD_USER_DETAILS);

			preparedStatement1.setString(1, employee.getEmpFName());
			preparedStatement1.setString(2, employee.getEmpLName());
			preparedStatement1.setString(3, employee.getEmployeeId());
			queryResult1 = preparedStatement1.executeUpdate();
			if (queryResult1 == 0) {
				logger.error("Adding details failed!! ");
				throw new EMSException("Adding employee details failed!! ");
			}

			if (queryResult == 0) {
				logger.error(" Adding details failed!! ");
				throw new EMSException("Adding employee details failed!!");
			}

			else {
				logger.info("Employee details added successfully:");
				return empId;
			}
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new EMSException("Tehnical problem occured refer log");
		}

		finally {
			try {
				preparedStatement.close();
				connection.close();
			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new EMSException("Error in closing db connection");
			}
		}

	}
	@Override
	public Employee updateEmployeeById(Employee employee) throws EMSException {
		Connection connection = ConnectionProvider.getConnection();

		PreparedStatement preparedStatement = null;
		int queryResult = 0;

		try {
			preparedStatement = connection
					.prepareStatement(IQueryMapper.UPDATE_EMPLOYEE_BY_ID);
			preparedStatement.setString(11, employee.getEmployeeId());
			preparedStatement.setString(1, employee.getEmpFName());
			preparedStatement.setString(2, employee.getEmpLName());
			preparedStatement.setInt(3, employee.getDeptId());
			preparedStatement.setString(4, employee.getEmpGrade());
			preparedStatement.setString(5, employee.getEmpDesignation());
			preparedStatement.setDouble(6, employee.getEmpBasic());
			preparedStatement.setString(7, employee.getEmpMStatus());
			preparedStatement.setString(8, employee.getHomeAddr());
			preparedStatement.setString(9, employee.getEmpCNumber());
			preparedStatement.setString(10, employee.getMrgId());

			queryResult = preparedStatement.executeUpdate();

			if (queryResult == 0) {
				logger.error("Updation failed ");
				throw new EMSException("Updating employee details failed ");

			} else {
				logger.info("Employee details updated successfully:");
				return employee;
			}
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new EMSException("Tehnical problem occured!!");
		}

		finally {
			try {
				// resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new EMSException("Error in closing db connection");
			}
		}

	}
	@Override
	public boolean leaveSanction(int leaveId, String status) throws EMSException {
		Connection connection = ConnectionProvider.getConnection();
		PreparedStatement preparedStatement = null;

		int queryResult = 0;
		try {
			preparedStatement = connection
					.prepareStatement(IQueryMapper.LEAVE_SANCTION_QUERY);
			preparedStatement.setInt(2, leaveId);
			preparedStatement.setString(1, status);
			queryResult = preparedStatement.executeUpdate();
			if (status.equals("approved")) {

				preparedStatement.close();
				preparedStatement = connection
						.prepareStatement(IQueryMapper.GET_EMPID_BY_LEAVE_ID_QUERY);
				preparedStatement.setInt(1, leaveId);
				ResultSet resultSet = preparedStatement.executeQuery();
				if (resultSet.next()) {
					String empId = null;
					int duration = 0;
					empId = resultSet.getString(1);
					duration = resultSet.getInt(2);
					PreparedStatement preparedStatement1 = null;
					preparedStatement1 = connection
							.prepareStatement(IQueryMapper.UPDATE_REMAINING_LEAVES_QUERY);
					preparedStatement1.setInt(1, duration);
					preparedStatement1.setString(2, empId);
					preparedStatement1.executeUpdate();
					preparedStatement1 = connection
							.prepareStatement(IQueryMapper.UPDATE_LEAVE_BALANCE);
					preparedStatement1.setInt(1, duration);
					preparedStatement1.setInt(2, leaveId);
					preparedStatement1.executeUpdate();
					preparedStatement1.close();
				}

			}
			if (queryResult == 0) {
				logger.error("Approval for leave failed ");
				throw new EMSException("Approving Leave details failed ");
			} else {
				logger.info("Leave details modified successfully:");
				return true;
			}

		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new EMSException("Tehnical problem occured refer log");
		}

		finally {
			try {
				// resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new EMSException("Error in closing db connection");
			}
		}

	}
	@Override
	public List<LeaveHistory> viewLeaveApplications() throws EMSException {
		Connection con = ConnectionProvider.getConnection();
		int leaveCount = 0;

		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		List<LeaveHistory> leaveList = new ArrayList<LeaveHistory>();
		try {
			preparedStatement = con.prepareStatement(IQueryMapper.RETRIEVE_APPLIED_LEAVE_QUERY);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				LeaveHistory bean = new LeaveHistory();
				bean.setLeaveId(resultSet.getInt(1));
				bean.setEmpId(resultSet.getString(2));
				bean.setDateFrom(resultSet.getDate(3).toLocalDate());
				bean.setNoofdays(resultSet.getInt(4));
				bean.setLeaveBalance(resultSet.getInt(5));
				bean.setStatus(resultSet.getString(6));
				leaveList.add(bean);
				leaveCount++;
			}

		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new EMSException("Tehnical problem occured. Refer log");
		}

		finally {
			try {
				resultSet.close();
				preparedStatement.close();
				con.close();
			} catch (SQLException exception) {
				logger.error(exception.getMessage());
				throw new EMSException("Error in closing db connection");
			}
		}

		if (leaveCount == 0)
			return null;
		else
			return leaveList;
	}
	
	@Override
	public int getRemainingLeaves(String empId) throws EMSException {
		Connection con = ConnectionProvider.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet;
		int remainingLeaves = 0;
		try {
			preparedStatement = con.prepareStatement(IQueryMapper.GET_LEAVE_BY_ID);
			preparedStatement.setString(1, empId);
			resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				remainingLeaves = resultSet.getInt(1);
			}

		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new EMSException("Tehnical problem occured. Refer log");
		}

		return remainingLeaves;
	}
	@Override
	public List<LeaveHistory> checkAppliedLeaves(String empId) throws EMSException {
		Connection con = ConnectionProvider.getConnection();
		int leaveCount = 0;

		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		List<LeaveHistory> leaveList = new ArrayList<LeaveHistory>();
		try {
			preparedStatement = con.prepareStatement(IQueryMapper.RETRIEVE_APPLIED_LEAVE_BY_EMPID_QUERY);
			preparedStatement.setString(1, empId);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				LeaveHistory bean = new LeaveHistory();
				bean.setLeaveId(resultSet.getInt(1));
				bean.setEmpId(resultSet.getString(2));
				bean.setDateFrom(resultSet.getDate(3).toLocalDate());
				bean.setNoofdays(resultSet.getInt(4));
				bean.setLeaveBalance(resultSet.getInt(5));
				bean.setStatus(resultSet.getString(6));
				leaveList.add(bean);
				leaveCount++;
			}

		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new EMSException("Tehnical problem occured. Refer log");
		}

		finally {
			try {
				resultSet.close();
				preparedStatement.close();
				con.close();
			} catch (SQLException exception) {
				logger.error(exception.getMessage());
				throw new EMSException("Error in closing db connection");
			}
		}

		if (leaveCount == 0)
			return null;
		else
			return leaveList;
	}
	
}
