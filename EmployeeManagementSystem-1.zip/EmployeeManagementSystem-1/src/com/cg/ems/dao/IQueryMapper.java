package com.cg.ems.dao;

public interface IQueryMapper {

	final String GET_USER = "select ";
	final String insertEmployee = "insert into Employee values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,12)";
	final String applyLeave = "insert into Leave_History values(leave_idseq.nextval,?,?,?,?,'applied',?)";
	final String getLeaveBalance = "select leave_balance from employee where emp_id=?";
	final String SELECT_BY_ID = null;
	final String LEAVE_REQUEST_QUERY = null;
	final String LEAVEID_QUERY_SEQUENCE = null;
	final String SELECT_BY_FNAME = null;
	final String SELECT_BY_LNAME = null;
	final String SELECT_BY_DEPT_NAME = null;
	final String SELECT_BY_GRADE = null;
	final String SELECT_BY_MARITAL_STATUS = null;
	final String RETRIEVE_ALL_DETAILS = null;
	final String ADD_EMPLOYEE = null;
	final String ADD_USER_DETAILS = null;
	final String UPDATE_EMPLOYEE_BY_ID = null;
	final String LEAVE_SANCTION_QUERY = null;
	final String GET_EMPID_BY_LEAVE_ID_QUERY = null;
	final String UPDATE_REMAINING_LEAVES_QUERY = null;
	final String UPDATE_LEAVE_BALANCE = null;
	final String RETRIEVE_APPLIED_LEAVE_QUERY = null;
	final String GET_LEAVE_BY_ID = null;
	final String RETRIEVE_APPLIED_LEAVE_BY_EMPID_QUERY = null;

}
