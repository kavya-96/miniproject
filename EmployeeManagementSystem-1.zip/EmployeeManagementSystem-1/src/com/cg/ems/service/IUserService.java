package com.cg.ems.service;

import com.cg.ems.exception.EMSException;



public interface IUserService {
	String getRole(String userName, String password) throws EMSException;

	String getUserId(String userName, String password) throws EMSException;
}
