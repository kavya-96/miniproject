package com.cg.ems.service;

import java.util.List;

import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employee;
import com.cg.ems.model.LeaveHistory;

public interface IAdminService {

	public String addEmployee(Employee employee) throws EMSException;
	
	public Employee updateEmployeeById(Employee employee) throws EMSException;
	
	public boolean leaveSanction(int leaveId, String status) throws EMSException;

	public List<LeaveHistory> viewLeaveApplications() throws EMSException;

	public void validateLeave(LeaveHistory leave) throws EMSException;

	public int getRemainingLeaves(String empId) throws EMSException;

	public List<LeaveHistory> checkAppliedLeaves(String empId) throws EMSException;
	

}
