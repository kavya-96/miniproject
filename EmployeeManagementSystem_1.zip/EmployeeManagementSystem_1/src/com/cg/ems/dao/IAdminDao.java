package com.cg.ems.dao;

import java.util.List;

import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employee;

public interface IAdminDao {

	
	boolean addEmployee(Employee employee) throws EMSException;
	boolean fetchEmployee(String empId)throws EMSException;
	List<Employee> displayAll() throws EMSException;
	boolean updateEmployee(String employeeId, Employee employee) throws EMSException;

}
