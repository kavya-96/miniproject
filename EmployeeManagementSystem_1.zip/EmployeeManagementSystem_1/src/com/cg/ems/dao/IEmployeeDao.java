package com.cg.ems.dao;



import com.cg.ems.model.Employee;


public interface IEmployeeDao {

	//Employee findEmployee(String employeeId);

	

	
}
