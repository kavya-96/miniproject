package com.cg.ems.dao;

public interface IQueryMapper {

	final String GET_USER = "select ";
	final String insertEmployee = "insert into employee values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	final String applyLeave = "insert into Leave_History values(leave_idseq.nextval,?,?,?,?,'applied')";
	final String getLeaveBalance = "select leave_balance from employee whrere emp_id=?";
	final String updateEmployee = "update employee set Emp_First_Name=?,Emp_Last_Name=?,"
			+ "Emp_Date_of_Birth=?,Emp_Date_of_Joining=?,"
			+ "Emp_Dept_ID=?,Emp_Grade=?,Emp_Designation=?,Emp_Basic=?,Emp_Gender=?,Emp_Martital_Status=?,"
			+ "Emp_Home_Address=?,Emp_Contact_Num=?,Mgr_Id=? "
			+ "where Emp_Id=?";
	final String fetchEmployeeQuery = "select * from employee where Emp_Id = ?";
	final String displayEmployees = "select * from employee";

}
