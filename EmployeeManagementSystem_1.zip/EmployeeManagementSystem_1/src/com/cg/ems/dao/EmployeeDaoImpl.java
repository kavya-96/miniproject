package com.cg.ems.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.DayOfWeek;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ems.exception.EMSException;
import com.cg.ems.model.LeaveHistory;
import com.cg.ems.util.ConnectionProvider;




public class EmployeeDaoImpl implements IEmployeeDao {

	Connection connection=null;
	PreparedStatement statement=null;
	
	/*@Override
	public boolean applyForLeave(LeaveHistory leaveHistory) throws EMSException {
   connection = ConnectionProvider.getConnection();
		
		boolean flag=false;
		try
		{
			int balance=getLeaveBalance(leaveHistory.getEmpId());
			statement=connection.prepareStatement(IQueryMapper.applyLeave);
	
			statement.setString(1,leaveHistory.getEmpId());
			
			
			statement.setInt(2,balance);
		
			int numberOfDays=DayleaveHistory.getDateTo()-leaveHistory.getDateFrom();
			statement.setString(3,employee.getEmpLName());
			Date empDob=new Date(employee.getEmpDOB().getTime());
			statement.setDate(4,empDob);
			Date empDoj=new Date(employee.getEmpDOJ().getTime());
			statement.setDate(5,empDoj);
			statement.setInt(6,employee.getDeptId());
			statement.setString(7,employee.getEmpGrade());*/
	
		
	/*} catch (SQLException e) {
			logger.error("statemnt object not created");
			throw new EMSException("statement not created with som problem");
	}

		return false;

}*/
//	private int getLeaveBalance(String empId) throws EMSException {
//		 connection = ConnectionProvider.getConnection();
//		 int balance=0;
//		 try {
//			statement=connection.prepareStatement(IQueryMapper.getLeaveBalance);
//			statement.setString(1,empId);
//			 ResultSet resultSet=statement.executeQuery();
//			 
//			 resultSet.next();
//			balance=resultSet.getInt(1);
//		} catch (SQLException e) {
//			throw new EMSException("statement not created with som problem");
//		}
//		 catch (Exception e) {
//				throw new EMSException("Enter valid Employee Id");
//			}
//		return balance;
//	}*/
}