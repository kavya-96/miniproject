package com.cg.ems.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ems.dao.IEmployeeDao;
import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employee;
import com.cg.ems.model.LeaveHistory;


public class EmployeeServiceImpl implements IEmployeeService {

	private IEmployeeDao empDao;
/*
	@Override
	public Employee findEmployee(String EmployeeId) throws EMSException {
		
		return empDao.findEmployee(EmployeeId);
	}*/

	@Override
	public Employee findEmployee(String EmployeeId) throws EMSException {
		// TODO Auto-generated method stub
		return null;
	}

	/*@Override
	public boolean applyForLeave(LeaveHistory leaveHistory) {
		// TODO Auto-generated method stub
		return empDao.applyForLeave(leaveHistory);
	}
	*/
	

}
